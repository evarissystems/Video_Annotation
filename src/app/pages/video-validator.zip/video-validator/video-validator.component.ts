import { Component, ElementRef, ViewChild } from "@angular/core";
import { UserProfileService } from "src/app/core/services/user.service";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { DomSanitizer, SafeResourceUrl } from "@angular/platform-browser";

@Component({
  selector: "app-video-validator",
  templateUrl: "./video-validator.component.html",
  styleUrls: ["./video-validator.component.scss"],
})
export class VideoValidatorComponent {
  @ViewChild("videoElement", { static: true })
  videoElement!: ElementRef;
  @ViewChild("startTimeInput", { static: true })
  startTimeInput!: ElementRef;
  @ViewChild("canvas") canvasRef: ElementRef;
  myForm: FormGroup;

  // responseData: any = [];
  data: any = [];
  Video_id: any;

  isPlaying: boolean = false;
  isDisabled: boolean = true;
  currentTime: any;
  endCurrentTime: any;
  retrievedValue: any;
  currentIndex: any;
  image_Name: any;
  videoPlayer: any;
  start_time: any;
  myImage: HTMLImageElement;
  imageName: any;
  video_Name: any;
  name: any;
  videoUrl: SafeResourceUrl;
  private canvas!: HTMLCanvasElement;
  private ctx!: CanvasRenderingContext2D;
  annotateImg: boolean = true;
  // private rectangles: Rectangle[] = [];
  private canvas2!: HTMLCanvasElement;

  constructor(
    private apiService: UserProfileService,

    private sanitizer: DomSanitizer
  ) {
    // ) {
    //   this.myForm = this.fb.group({
    //     subject: ["", [Validators.required]],
    //     question: ["", [Validators.required]],
    //     keyPerson1: ["", [Validators.required]],
    //     keyPerson2: ["", [Validators.required]],
    //     location: ["", [Validators.required]],
    //     tag2: ["", [Validators.required]],
    //   });
  }

  // ngAfterViewInit() {
  //   this.canvas = this.canvasRef.nativeElement;
  //   // this.canvas2 = this.canvasRef2.nativeElement;
  //   const context = this.canvas.getContext("2d");
  //   if (context) {
  //     this.ctx = context;
  //   } else {
  //     throw new Error("Unable to obtain 2D rendering context.");
  //   }

  //   // this.search();
  //   // this.nextImage();
  // }

  playPause() {
    const video = this.videoElement.nativeElement;
    if (video.paused) {
      video.play();
    } else {
      video.pause();
    }
  }
  seekTo(): void {
    if (this.videoElement.nativeElement) {
      this.videoElement.nativeElement.currentTime = this.start_time;
    }
    this.playPause();
  }
  ngOnInit(): void {
    this.image_Name = this.data.imgName;
    this.Video_id = this.data.videoID;
    console.log(this.Video_id);
    const video_src = this.data.videoName;
    this.fetchData();

    this.getImageData();

    try {
      this.retrievedValue = localStorage.getItem("currentUser");
      console.log(this.retrievedValue);
      if (this.retrievedValue !== null) {
        // Value exists in local storage
        console.log(typeof this.retrievedValue);
      } else {
        // Key doesn't exist in local storage
        console.log("Key not found.");
      }
    } catch (error) {
      // Handle exceptions (e.g., local storage is disabled)
      console.error("Error accessing local storage:", error);
    }

    const url = this.data.getVideoUrl(video_src);
    console.log(url);
    this.videoUrl = this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }
  trackByFn(index: any, item: any): any {
    return item.start_time;
    return item.end_time;
  }

  fetchData() {
    this.apiService
      .fetchAnnotateData(this.Video_id)
      .subscribe((response: any) => {
        // Handle the API response here
        // this.data = response;
        console.log(response);
        this.data = response;
      });
  }

  getImageData() {
    this.currentIndex = 0;
    console.log(this.imageName);
    this.name = this.imageName[this.currentIndex];
    console.log(this.name);

    // if (this.currentIndex < this.totalImages) {
    const dataObj = {
      bookName: this.video_Name,
      imgName: this.name,
    };
    this.data.displayImg(dataObj).subscribe((response: any) => {
      console.log(response);
      this.myImage = new Image();
      this.myImage.src = "data:image/jpeg;base64," + response;
      // Reset the rectangles array
      // this.clearCanvas();
      // const context=this.canvas.nativeElement.getContext('2d');
      // console.log(myImage.src);
      this.myImage.onload = () => {
        this.ctx.drawImage(
          this.myImage,
          0,
          0,
          this.canvas.width,
          this.canvas.height
        );
      };
    });
  }

  // playVideo() {
  //   this.videoElement.nativeElement.play();
  //   this.isPlaying = true;
  // }

  // pauseVideo() {
  //   this.videoElement.nativeElement.pause();
  //   this.isPlaying = false;
  // }

  startButtonClick() {
    const video = this.videoElement.nativeElement as HTMLVideoElement;
    const currentTime = video.currentTime;
    console.log(`Start Time: ${this.formatTime(currentTime)}`);
    // console.log(currentTime);
    // return this.currentTime.toFixed(2);
    this.currentTime = this.formatTime(currentTime);
    // this.startBtnClick = false;
    this.isDisabled = false;
  }

  EndButtonClick() {
    const video = this.videoElement.nativeElement as HTMLVideoElement;
    const currentTime = video.currentTime;
    console.log(`End Time: ${this.formatTime(currentTime)}`);
    // console.log(currentTime);
    // return this.currentTime.toFixed(2);
    this.endCurrentTime = this.formatTime(currentTime);
    // this.startBtnClick = false;
    this.isDisabled = true;
  }

  formatTime(time: number): string {
    const minutes = Math.floor(time / 60);
    const seconds = Math.ceil(time % 60);
    const milliseconds = Math.floor((time % 1) * 1000);
    return `${minutes}:${String(seconds).padStart(2, "0")}:${String(
      milliseconds
    ).padStart(3, "0")}`;
  }
}
